class FinTrackDBEntry:
    def __init__(self,
                 id=1,
                 date=1,
                 cf_type='=',
                 earning='=',
                 expense='=',
                 paymode='=',
                 amount=1):
        self.id = id
        self.date = date
        self.cf_type = cf_type
        self.earning = earning
        self.expense = expense
        self.paymode = paymode
        self.amount = amount
        

