import FinTrackDBSQ

def test_insert():
    for entry in range(30):
        FinTrackDBSQ.insert_statement(entry, f'1', f'230101', 'Earning', 'Salary (Work)', '=', 'Cash', f'1000')
        assert FinTrackDBSQ.id_exists(entry)

    all_entries = FinTrackDBSQ.fetch_statements()
    assert len(all_entries) == 30

def test_update():
    for entry in range(10, 20):
        FinTrackDBSQ.update_statement(f'1', f'230101', 'Earning', 'Salary (Work)', '=', 'Cash', f'1000', entry)
        assert FinTrackDBSQ.id_exists(entry)

    all_entries = FinTrackDBSQ.fetch_statements()
    assert len(all_entries) == 30

def test_delete():
    for entry in range(10):
        FinTrackDBSQ.delete_statement(entry)
        assert not FinTrackDBSQ.id_exists(entry) 

    all_entries = FinTrackDBSQ.fetch_statements()
    assert len(all_entries) == 20